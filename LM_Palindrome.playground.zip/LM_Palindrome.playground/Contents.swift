import UIKit

// 2. Check to see if a string is a palindrome. No inbuilt methods.

func palindrome(_ testString: String)-> Bool{
    //convert to array to loop through
    let strArray = Array(testString)
    //test to see if half the word is ==
    for i in 0..<strArray.count / 2  {
        // offset by 1
        if strArray[i] != strArray[strArray.count - i - 1] {
            print("\(testString) is NOT a palindrome!")
            return false
        }
    }
    print("\(testString) is a palindrome!")
    return true
}

print(palindrome("civic"))
print(palindrome("abc"))
print(palindrome("xyx"))
print(palindrome("Leah"))

