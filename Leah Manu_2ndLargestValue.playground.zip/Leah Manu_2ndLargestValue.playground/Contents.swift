import UIKit

// 1. Find the second largest value in an array of integers

var myArray = [100, 10, 41, 14, 8, 74, 23, 55, 13, 4]

sortmyArray(myArray)

func sortmyArray(_ array: [Int]) {
    var myArr = array
    
    for i in 0..<myArr.count-1 {
        var min = i
        for y in i + 1 ..< myArr.count {
            if myArr[y] < myArr[min] {
                
                min = y
            }
        }
        if i != min {

            myArr.swapAt(i, min)
        }
    }
    print("The second largest value in myArray is ", (myArr[1]))
    print(myArr)

}
